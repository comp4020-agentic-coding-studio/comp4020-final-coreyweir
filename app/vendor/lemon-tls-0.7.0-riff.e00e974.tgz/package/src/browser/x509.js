import { ed25519 } from '@noble/curves/ed25519.js';

const textEncoder = new TextEncoder();
const ED25519_OID = [1, 3, 101, 112];
const COMMON_NAME_OID = [2, 5, 4, 3];
const BASIC_CONSTRAINTS_OID = [2, 5, 29, 19];
const KEY_USAGE_OID = [2, 5, 29, 15];
const EXTENDED_KEY_USAGE_OID = [2, 5, 29, 37];
const SUBJECT_ALT_NAME_OID = [2, 5, 29, 17];
const SERVER_AUTH_OID = [1, 3, 6, 1, 5, 5, 7, 3, 1];

function bytes(...parts) {
  const length = parts.reduce((total, part) => total + part.length, 0);
  const result = new Uint8Array(length);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}

function length(value) {
  if (value < 0x80) return Uint8Array.of(value);
  const encoded = [];
  for (let number = value; number > 0; number >>>= 8) encoded.unshift(number & 0xff);
  return Uint8Array.of(0x80 | encoded.length, ...encoded);
}

function der(tag, value) {
  return bytes(Uint8Array.of(tag), length(value.length), value);
}

function sequence(...values) {
  return der(0x30, bytes(...values));
}

function set(...values) {
  return der(0x31, bytes(...values));
}

function integer(value) {
  let start = 0;
  while (start < value.length - 1 && value[start] === 0) start++;
  const unsigned = value.subarray(start);
  return der(0x02, unsigned[0] & 0x80 ? bytes(Uint8Array.of(0), unsigned) : unsigned);
}

function oid(parts) {
  const encoded = [parts[0] * 40 + parts[1]];
  for (const part of parts.slice(2)) {
    const groups = [part & 0x7f];
    for (let value = part >>> 7; value > 0; value >>>= 7) groups.unshift(0x80 | (value & 0x7f));
    encoded.push(...groups);
  }
  return der(0x06, Uint8Array.from(encoded));
}

function algorithm() {
  return sequence(oid(ED25519_OID));
}

function name(commonName) {
  return sequence(set(sequence(oid(COMMON_NAME_OID), der(0x0c, textEncoder.encode(commonName)))));
}

function time(date) {
  const year = date.getUTCFullYear();
  const value = `${String(year % 100).padStart(2, '0')}${String(date.getUTCMonth() + 1).padStart(2, '0')}${String(date.getUTCDate()).padStart(2, '0')}${String(date.getUTCHours()).padStart(2, '0')}${String(date.getUTCMinutes()).padStart(2, '0')}${String(date.getUTCSeconds()).padStart(2, '0')}Z`;
  return der(year < 2050 ? 0x17 : 0x18, textEncoder.encode(value));
}

function bitString(value, unusedBits = 0) {
  return der(0x03, bytes(Uint8Array.of(unusedBits), value));
}

function extension(identifier, value, critical = false) {
  return sequence(oid(identifier), ...(critical ? [der(0x01, Uint8Array.of(0xff))] : []), der(0x04, value));
}

function subjectPublicKey(publicKey) {
  return sequence(algorithm(), bitString(publicKey));
}

function serial(random) {
  const result = random.slice(0, 20);
  result[0] &= 0x7f;
  if (result.every((value) => value === 0)) result[result.length - 1] = 1;
  return result;
}

function randomBytes(length) {
  const result = new Uint8Array(length);
  globalThis.crypto.getRandomValues(result);
  return result;
}

function validity(now) {
  const start = new Date(now.getTime() - 60_000);
  const end = new Date(now.getTime());
  end.setUTCFullYear(end.getUTCFullYear() + 2);
  return sequence(time(start), time(end));
}

function tbs({ issuer, subject, publicKey, extensions, now }) {
  return sequence(
    der(0xa0, integer(Uint8Array.of(2))),
    integer(serial(randomBytes(20))),
    algorithm(),
    issuer,
    validity(now),
    subject,
    subjectPublicKey(publicKey),
    der(0xa3, sequence(...extensions)),
  );
}

function certificate(tbsCertificate, signingKey) {
  return sequence(tbsCertificate, algorithm(), bitString(ed25519.sign(tbsCertificate, signingKey)));
}

function pem(label, derBytes) {
  let binary = '';
  for (const byte of derBytes) binary += String.fromCharCode(byte);
  const body = btoa(binary).replace(/.{64}/g, '$&\n');
  return `-----BEGIN ${label}-----\n${body}\n-----END ${label}-----\n`;
}

function isDnsName(hostname) {
  return hostname.length <= 253 && hostname.split('.').every((label) =>
    label.length > 0 && label.length <= 63 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label));
}

function ipv4(hostname) {
  const parts = hostname.split('.');
  if (parts.length !== 4) return null;
  const octets = parts.map((part) => Number(part));
  if (!octets.every((value, index) => /^\d+$/.test(parts[index]) && value >= 0 && value <= 255)) return null;
  return Uint8Array.from(octets);
}

function subjectAlternativeName(hostname) {
  const address = ipv4(hostname);
  if (address) return extension(SUBJECT_ALT_NAME_OID, sequence(der(0x87, address)));
  if (!isDnsName(hostname)) throw new Error(`unsupported certificate hostname: ${hostname}`);
  return extension(SUBJECT_ALT_NAME_OID, sequence(der(0x82, textEncoder.encode(hostname))));
}

export function createCertificateAuthority(commonName = 'WASIX Browser Gateway') {
  const privateKey = randomBytes(32);
  const publicKey = ed25519.getPublicKey(privateKey);
  const now = new Date();
  const subject = name(commonName);
  const derBytes = certificate(tbs({
    issuer: subject,
    subject,
    publicKey,
    now,
    extensions: [
      extension(BASIC_CONSTRAINTS_OID, sequence(der(0x01, Uint8Array.of(0xff))), true),
      extension(KEY_USAGE_OID, bitString(Uint8Array.of(0x06), 1), true),
    ],
  }), privateKey);
  return { privateKey, publicKey, der: derBytes, pem: pem('CERTIFICATE', derBytes), subject };
}

export function createLeafCertificate(authority, hostname) {
  const privateKey = randomBytes(32);
  const publicKey = ed25519.getPublicKey(privateKey);
  const subject = name(hostname);
  const derBytes = certificate(tbs({
    issuer: authority.subject,
    subject,
    publicKey,
    now: new Date(),
    extensions: [
      extension(BASIC_CONSTRAINTS_OID, sequence()),
      extension(KEY_USAGE_OID, bitString(Uint8Array.of(0x80), 7), true),
      extension(EXTENDED_KEY_USAGE_OID, sequence(oid(SERVER_AUTH_OID))),
      subjectAlternativeName(hostname),
    ],
  }), authority.privateKey);
  return { privateKey, publicKey, der: derBytes, certificateChain: [{ cert: derBytes }] };
}
