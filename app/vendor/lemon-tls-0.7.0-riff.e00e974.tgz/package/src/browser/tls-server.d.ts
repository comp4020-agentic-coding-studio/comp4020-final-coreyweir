export type BrowserCertificateAuthority = {
  privateKey: Uint8Array;
  publicKey: Uint8Array;
  der: Uint8Array;
  pem: string;
  subject: Uint8Array;
};

export class BrowserTlsServer {
  constructor(authority: BrowserCertificateAuthority);
  secure: boolean;
  closed: boolean;
  on(name: "output" | "data" | "secure" | "close" | "error", listener: (data?: Uint8Array | Error) => void): this;
  write(data: Uint8Array): void;
  send(data: Uint8Array): void;
  close(): void;
}
