function unavailable() {
  throw new Error('TLS session tickets are unavailable in the browser server profile');
}

export const encrypt_session_blob = unavailable;
export const decrypt_session_blob = unavailable;
export const encode_client_session = unavailable;
export const decode_client_session = unavailable;
