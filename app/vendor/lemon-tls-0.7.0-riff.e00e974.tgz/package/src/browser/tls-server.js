import { gcm } from '@noble/ciphers/aes.js';
import TLSSession from '../tls_session.js';
import { TLS_CONTENT_TYPE as CT } from '../wire.js';
import { hkdf_expand_label } from '../crypto.js';
import { createLeafCertificate } from './x509.js';
import { Emitter } from './emitter.js';

const MAX_RECORD = 16_384 + 256;

function concat(parts) {
  const length = parts.reduce((total, part) => total + part.length, 0);
  const result = new Uint8Array(length);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}

function frame(type, payload) {
  const result = new Uint8Array(5 + payload.length);
  result.set([type, 0x03, 0x03, payload.length >>> 8, payload.length & 0xff]);
  result.set(payload, 5);
  return result;
}

function deriveKeys(secret) {
  const empty = new Uint8Array(0);
  return {
    key: hkdf_expand_label('sha256', secret, 'key', empty, 16, 'tls13 '),
    iv: hkdf_expand_label('sha256', secret, 'iv', empty, 12, 'tls13 '),
  };
}

function nonce(iv, sequence) {
  const result = new Uint8Array(iv);
  const high = Math.floor(sequence / 0x1_0000_0000);
  const low = sequence >>> 0;
  result[4] ^= (high >>> 24) & 0xff;
  result[5] ^= (high >>> 16) & 0xff;
  result[6] ^= (high >>> 8) & 0xff;
  result[7] ^= high & 0xff;
  result[8] ^= (low >>> 24) & 0xff;
  result[9] ^= (low >>> 16) & 0xff;
  result[10] ^= (low >>> 8) & 0xff;
  result[11] ^= low & 0xff;
  return result;
}

function parseInnerPlaintext(data) {
  let index = data.length - 1;
  while (index >= 0 && data[index] === 0) index--;
  if (index < 0) throw new Error('malformed TLSInnerPlaintext');
  return { type: data[index], content: data.subarray(0, index) };
}

function encrypt(type, payload, key, iv, sequence) {
  const length = payload.length + 17;
  const header = Uint8Array.of(CT.APPLICATION_DATA, 0x03, 0x03, length >>> 8, length & 0xff);
  const plaintext = new Uint8Array(payload.length + 1);
  plaintext.set(payload);
  plaintext[payload.length] = type;
  const ciphertext = gcm(key, nonce(iv, sequence), header).encrypt(plaintext);
  return concat([header, ciphertext]);
}

function decrypt(header, payload, key, iv, sequence) {
  return parseInnerPlaintext(gcm(key, nonce(iv, sequence), header).decrypt(payload));
}

/**
 * Restricted TLS 1.3 server for the browser fetch gateway. It deliberately
 * exposes bytes, not a Node stream, so callers can bridge a WASIX socket.
 */
export class BrowserTlsServer extends Emitter {
  constructor(authority) {
    super();
    this.authority = authority;
    this.input = new Uint8Array(0);
    this.handshake = new Uint8Array(0);
    this.handshakeReadSequence = 0;
    this.handshakeWriteSequence = 0;
    this.applicationReadSequence = 0;
    this.applicationWriteSequence = 0;
    this.secure = false;
    this.closed = false;
    this.keys = {};
    this.session = new TLSSession({
      isServer: true,
      sessionTickets: false,
      SNICallback: (hostname, done) => {
        try {
          const leaf = createLeafCertificate(authority, hostname);
          done(null, {
            certificateChain: leaf.certificateChain,
            privateKey: { asymmetricKeyType: 'ed25519', privateKey: leaf.privateKey },
          });
        } catch (error) {
          done(error);
        }
      },
    });
    this.session.on('hello', () => this.session.set_context({
      local_supported_versions: [0x0304],
      local_supported_cipher_suites: [0x1301],
      local_supported_groups: [0x001d],
      local_supported_signature_algorithms: [0x0807],
    }));
    this.session.on('message', (epoch, _sequence, type, data) => this.#sendSessionMessage(epoch, type, data));
    this.session.on('secureConnect', () => {
      this.secure = true;
      this.emit('secure');
    });
    this.session.on('error', (error) => this.#fail(error));
  }

  write(data) {
    if (this.closed) return;
    this.input = concat([this.input, new Uint8Array(data)]);
    while (this.input.length >= 5) {
      const length = (this.input[3] << 8) | this.input[4];
      if (length > MAX_RECORD) return this.#fail(new Error('TLS record exceeds configured limit'));
      if (this.input.length < 5 + length) return;
      const header = this.input.subarray(0, 5);
      const type = header[0];
      const payload = this.input.subarray(5, 5 + length);
      this.input = this.input.slice(5 + length);
      try {
        if (type === CT.CHANGE_CIPHER_SPEC) continue;
        if (type === CT.HANDSHAKE) this.#feedHandshake(payload);
        else if (type === CT.APPLICATION_DATA) this.#readCiphertext(header, payload);
        else if (type === CT.ALERT) this.close();
        else throw new Error(`unexpected TLS record type ${type}`);
      } catch (error) {
        this.#fail(error);
        return;
      }
    }
  }

  send(data) {
    if (!this.secure || this.closed) throw new Error('TLS application keys are not available');
    const bytes = new Uint8Array(data);
    for (let offset = 0; offset < bytes.length; offset += 16_384) {
      this.#sendEncrypted(CT.APPLICATION_DATA, bytes.subarray(offset, offset + 16_384), 'application');
    }
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    if (this.secure) {
      try { this.#sendEncrypted(CT.ALERT, Uint8Array.of(1, 0), 'application'); } catch { /* already failed */ }
    }
    this.emit('close');
  }

  #feedHandshake(data) {
    this.handshake = concat([this.handshake, data]);
    while (this.handshake.length >= 4) {
      const length = (this.handshake[1] << 16) | (this.handshake[2] << 8) | this.handshake[3];
      if (this.handshake.length < 4 + length) return;
      this.session.message(this.handshake.slice(0, 4 + length));
      this.handshake = this.handshake.slice(4 + length);
    }
  }

  #readCiphertext(header, payload) {
    const phase = this.secure ? 'application' : 'handshake';
    const keys = this.#keys(phase, false);
    const sequence = phase === 'application' ? this.applicationReadSequence++ : this.handshakeReadSequence++;
    const inner = decrypt(header, payload, keys.key, keys.iv, sequence);
    if (inner.type === CT.HANDSHAKE) this.#feedHandshake(inner.content);
    else if (inner.type === CT.APPLICATION_DATA && this.secure) this.emit('data', inner.content);
    else if (inner.type === CT.ALERT) this.close();
    else throw new Error(`unexpected encrypted TLS content type ${inner.type}`);
  }

  #sendSessionMessage(epoch, type, data) {
    if (this.closed) return;
    if (epoch === 0) {
      this.emit('output', frame(type === 'alert' ? CT.ALERT : CT.HANDSHAKE, data));
      return;
    }
    this.#sendEncrypted(type === 'alert' ? CT.ALERT : CT.HANDSHAKE, data, epoch === 1 ? 'handshake' : 'application');
  }

  #sendEncrypted(type, data, phase) {
    const keys = this.#keys(phase, true);
    const sequence = phase === 'application' ? this.applicationWriteSequence++ : this.handshakeWriteSequence++;
    this.emit('output', encrypt(type, data, keys.key, keys.iv, sequence));
  }

  #keys(phase, local) {
    const cache = `${phase}-${local ? 'write' : 'read'}`;
    if (!this.keys[cache]) {
      const secrets = phase === 'application' ? this.session.getTrafficSecrets() : this.session.getHandshakeSecrets();
      const secret = phase === 'application'
        ? local ? secrets.localAppSecret : secrets.remoteAppSecret
        : local ? secrets.localSecret : secrets.remoteSecret;
      if (!secret || secrets.cipher !== 0x1301) throw new Error('TLS browser profile did not negotiate AES-128-GCM/SHA-256');
      this.keys[cache] = deriveKeys(secret);
    }
    return this.keys[cache];
  }

  #fail(error) {
    if (this.closed) return;
    this.closed = true;
    this.emit('error', error instanceof Error ? error : new Error(String(error)));
    this.emit('close');
  }
}
