import { sha256 } from '@noble/hashes/sha2.js';

function concat(parts) {
  const length = parts.reduce((total, part) => total + part.length, 0);
  const result = new Uint8Array(length);
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}

class Hash {
  constructor(parts = []) { this.parts = parts; }
  update(data) { this.parts.push(new Uint8Array(data)); return this; }
  copy() { return new Hash(this.parts.slice()); }
  digest() { return sha256(concat(this.parts)); }
}

export function randomBytes(length) {
  const result = new Uint8Array(length);
  globalThis.crypto.getRandomValues(result);
  return result;
}

export function createHash(name) {
  if (name !== 'sha256') throw new Error(`browser TLS only supports sha256, not ${name}`);
  return new Hash();
}

// These APIs belong to client-authentication and certificate-inspection paths
// deliberately excluded from the browser gateway profile. Exporting explicit
// failures keeps accidental use observable and lets bundlers resolve the
// upstream session module without substituting a Node compatibility shim.
export class X509Certificate {
  constructor() {
    throw new Error('browser TLS does not parse peer X.509 certificates');
  }
}

export function createPrivateKey() {
  throw new Error('browser TLS credentials use browser-generated Ed25519 keys');
}
