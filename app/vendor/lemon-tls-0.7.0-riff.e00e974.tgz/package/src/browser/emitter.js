export class Emitter {
  #listeners = new Map();

  on(name, listener) {
    const listeners = this.#listeners.get(name) ?? [];
    listeners.push(listener);
    this.#listeners.set(name, listeners);
    return this;
  }

  off(name, listener) {
    const listeners = this.#listeners.get(name);
    if (!listeners) return this;
    this.#listeners.set(name, listeners.filter((candidate) => candidate !== listener));
    return this;
  }

  emit(name, ...args) {
    for (const listener of this.#listeners.get(name) ?? []) listener(...args);
    return this.#listeners.has(name);
  }

  listenerCount(name) {
    return this.#listeners.get(name)?.length ?? 0;
  }
}
