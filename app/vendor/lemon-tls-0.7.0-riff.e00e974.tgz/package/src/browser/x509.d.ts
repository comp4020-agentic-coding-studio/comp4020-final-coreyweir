import type { BrowserCertificateAuthority } from "./tls-server.js";

export function createCertificateAuthority(commonName?: string): BrowserCertificateAuthority;
