export default function createSecureContext(options) {
  if (!options?.certificateChain || !options?.privateKey) {
    throw new Error('browser TLS credentials require certificateChain and privateKey');
  }
  return options;
}
